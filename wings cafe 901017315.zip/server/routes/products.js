const express = require('express');
const router = express.Router();
const db = require('../db');

// Get all products
router.get('/', async (req, res) => {
    try {
        const [products] = await db.query('SELECT * FROM products');
        res.json(products);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching products' });
    }
});

// Add a new product
router.post('/', async (req, res) => {
    const { name, description, category, price, quantity } = req.body;
    try {
        await db.query(
            'INSERT INTO products (name, description, category, price, quantity) VALUES (?, ?, ?, ?, ?)',
            [name, description, category, price, quantity]
        );
        res.json({ message: 'Product added successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error adding product' });
    }
});

// Update a product
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { name, description, category, price, quantity } = req.body;
    try {
        await db.query(
            'UPDATE products SET name = ?, description = ?, category = ?, price = ?, quantity = ? WHERE id = ?',
            [name, description, category, price, quantity, id]
        );
        res.json({ message: 'Product updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error updating product' });
    }
});

// Delete a product
router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await db.query('DELETE FROM products WHERE id = ?', [id]);
        res.json({ message: 'Product deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error deleting product' });
    }
});

module.exports = router;
