const express = require('express');
const router = express.Router();
const db = require('../db');

// Route to get all users
router.get('/', async (req, res) => {
    const [users] = await db.query('SELECT username FROM users');
    res.json(users);
});

// Route to add a new user
router.post('/signup', async (req, res) => {
    const { username, password } = req.body;
    await db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password]);
    res.json({ message: 'User added successfully' });
});

// Route to delete a user
router.delete('/:username', async (req, res) => {
    const { username } = req.params;
    await db.query('DELETE FROM users WHERE username = ?', [username]);
    res.json({ message: 'User deleted successfully' });
});

module.exports = router;
