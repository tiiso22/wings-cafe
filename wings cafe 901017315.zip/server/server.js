const express = require('express');
const router = express.Router();
const db = require('../db');

// Get all users (excluding passwords for security)
router.get('/', async (req, res) => {
    try {
        const [users] = await db.query('SELECT username FROM users');
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching users' });
    }
});

// Add a new user (sign-up)
router.post('/signup', async (req, res) => {
    const { username, password } = req.body;
    try {
        await db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password]);
        res.json({ message: 'User signed up successfully' });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            res.status(400).json({ error: 'Username already exists' });
        } else {
            res.status(500).json({ error: 'Error signing up user' });
        }
    }
});

// Delete a user
router.delete('/:username', async (req, res) => {
    const { username } = req.params;
    try {
        await db.query('DELETE FROM users WHERE username = ?', [username]);
        res.json({ message: 'User deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error deleting user' });
    }
});

module.exports = router;
