document.addEventListener('DOMContentLoaded', function () {
    displayDashboard();
});

function displayDashboard() {
    const products = getFromLocal('products');
    const tableBody = document.getElementById('stock-table').querySelector('tbody');
    tableBody.innerHTML = '';

    products.forEach(product => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${product.name}</td>
            <td>${product.quantity}</td>
        `;
        tableBody.appendChild(row);
    });
}

document.getElementById('logoutBtn').addEventListener('click', function() {
    alert('You have logged out.');
    window.location.href = 'login.html';
});
