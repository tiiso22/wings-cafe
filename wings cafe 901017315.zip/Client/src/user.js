document.addEventListener('DOMContentLoaded', displayUsers);

// Function to handle user sign-up
function handleSignup(event) {
    event.preventDefault();
    const username = document.getElementById('signupUsername').value;
    const password = document.getElementById('signupPassword').value;

    const user = { username, password };
    saveToLocal('users', user);

    displayUsers();
    event.target.reset();
}

// Function to display users in the table
function displayUsers() {
    const users = getFromLocal('users');
    const tableBody = document.getElementById('user-table').querySelector('tbody');
    tableBody.innerHTML = '';

    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${user.username}</td>
            <td><button onclick="deleteUser('${user.username}')">Delete</button></td>
        `;
        tableBody.appendChild(row);
    });
}

// Function to delete a user
function deleteUser(username) {
    deleteFromLocal('users', username);
    displayUsers();
}

// Function to handle user login
function handleLogin(event) {
    event.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const users = getFromLocal('users');
    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        alert('Login successful');
        window.location.href = 'index.html';
    } else {
        alert('Invalid username or password');
    }
}

