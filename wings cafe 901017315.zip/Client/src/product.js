document.addEventListener('DOMContentLoaded', displayProducts);

function handleProductSubmit(event) {
    event.preventDefault();
    const name = document.getElementById('productName').value;
    const description = document.getElementById('productDescription').value;
    const category = document.getElementById('productCategory').value;
    const price = parseFloat(document.getElementById('productPrice').value);
    const quantity = parseInt(document.getElementById('productQuantity').value);

    const product = { name, description, category, price, quantity };
    saveToLocal('products', product);
    displayProducts();
    event.target.reset();
}

function displayProducts() {
    const products = getFromLocal('products');
    const tableBody = document.getElementById('product-table').querySelector('tbody');
    tableBody.innerHTML = '';
    products.forEach(product => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${product.name}</td>
            <td>${product.description}</td>
            <td>${product.category}</td>
            <td>${product.price}</td>
            <td>${product.quantity}</td>
            <td><button onclick="deleteProduct('${product.name}')">Delete</button></td>
        `;
        tableBody.appendChild(row);
    });
}

function deleteProduct(productName) {
    deleteFromLocal('products', productName);
    displayProducts();
}
