function saveToLocal(key, value) {
    const data = getFromLocal(key);
    data.push(value);
    localStorage.setItem(key, JSON.stringify(data));
}

function getFromLocal(key) {
    return JSON.parse(localStorage.getItem(key)) || [];
}

function updateInLocal(key, updatedData) {
    localStorage.setItem(key, JSON.stringify(updatedData));
}

function deleteFromLocal(key, valueToDelete) {
    let data = getFromLocal(key);
    data = data.filter(item => item.username ? item.username !== valueToDelete : item.name !== valueToDelete);
    updateInLocal(key, data);
}
